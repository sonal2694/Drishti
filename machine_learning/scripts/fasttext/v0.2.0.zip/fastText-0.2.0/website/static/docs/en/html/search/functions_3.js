var searchData=
[
  ['dfs',['dfs',['../classfasttext_1_1Model.html#a16ffdb3fcd27fa51f6b435b3be762a77',1,'fasttext::Model']]],
  ['dictionary',['Dictionary',['../classfasttext_1_1Dictionary.html#ae0f87ea47dcc779231cd0d2cd660739e',1,'fasttext::Dictionary']]],
  ['discard',['discard',['../classfasttext_1_1Dictionary.html#a13572c258fc013c30b2dcf7cada260b5',1,'fasttext::Dictionary']]],
  ['distl2',['distL2',['../namespacefasttext.html#a4336b1849ad0c1f134ed0ac9842f053c',1,'fasttext']]],
  ['dividerow',['divideRow',['../classfasttext_1_1Matrix.html#ab4d6dd58db43dd2c4a6fbb12c74541a0',1,'fasttext::Matrix']]],
  ['dotrow',['dotRow',['../classfasttext_1_1Matrix.html#ae6b962ed2ca31fb3a8d094c8f85d6136',1,'fasttext::Matrix::dotRow()'],['../classfasttext_1_1QMatrix.html#ad1671bceb60d87492b662331cc084c56',1,'fasttext::QMatrix::dotRow()']]]
];
