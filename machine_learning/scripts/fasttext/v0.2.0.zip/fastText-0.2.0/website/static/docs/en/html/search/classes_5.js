var searchData=
[
  ['node',['Node',['../structfasttext_1_1Node.html',1,'fasttext']]]
];
